<?php get_header(); ?>

<main>
    <div id="root"></div>
</main>

<?php get_footer(); ?>
