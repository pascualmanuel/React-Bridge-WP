<?php
function mi_theme_setup() {
    // Soporte para el título de la página.
    add_theme_support('title-tag');

    // Registrar un menú.
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'mi-theme-vacio'),
    ));
}
add_action('after_setup_theme', 'mi_theme_setup');
